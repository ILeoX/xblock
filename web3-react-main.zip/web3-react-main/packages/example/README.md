# example

This is an example app built with [Next.js](https://nextjs.org/) that showcases some basic web3-react usage patterns.
