declare module 'eth-provider'
